package generics;

public interface MaxMinFinder<T extends Comparable<T>> {
    T findMax(T[] array);
    T findMin(T[] array);
}
