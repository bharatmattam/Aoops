package adapterpattern;

public interface AdvancedImageViewer {
    void showPng(String fileName);
    void showJpg(String fileName);
}
