package generics;

import java.util.Arrays;

public class BinarySearch<T extends Comparable<T>> {
    private T[] array;

    // Constructor to initialize the array
    public BinarySearch(T[] array) {
        Arrays.sort(array); // Binary search requires a sorted array
        this.array = array;
    }

    // Generic method to perform binary search
    public int search(T key) {
        int left = 0, right = array.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (array[mid].compareTo(key) == 0) {
                return mid; // Key found
            } else if (array[mid].compareTo(key) < 0) {
                left = mid + 1; // Search right half
            } else {
                right = mid - 1; // Search left half
            }
        }
        return -1; // Key not found
    }

    // Method to print the sorted array
    public void printArray() {
        System.out.println("Sorted Array: " + Arrays.toString(array));
    }
}
