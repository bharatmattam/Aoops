package mypackage;

public class BasicMusicPlayer implements MusicPlayer{
	public void playMusic(MusicSource source) {
		System.out.println("Using basic player");
		source.play();
	}

}
