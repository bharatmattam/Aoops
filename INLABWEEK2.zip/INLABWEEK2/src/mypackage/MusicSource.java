package mypackage;

interface MusicSource {
    void play();
}
