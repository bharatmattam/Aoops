package mypackage;

class EqualizerDecorator extends MusicPlayerDecorator {
    public EqualizerDecorator(MusicPlayer decoratedPlayer) {
        super(decoratedPlayer);
    }

    @Override
    public void playMusic(MusicSource source) {
        System.out.println("Applying equalizer settings...");
        super.playMusic(source);
    }
}
