package mypackage;

public interface MusicPlayer {
	void playMusic(MusicSource source);
}
