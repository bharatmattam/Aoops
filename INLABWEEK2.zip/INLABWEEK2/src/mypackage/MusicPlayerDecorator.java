package mypackage;

abstract class MusicPlayerDecorator implements MusicPlayer{
	protected MusicPlayer decoratedPlayer;
	
	public MusicPlayerDecorator(MusicPlayer decoratedPlayer) {
		this.decoratedPlayer=decoratedPlayer;
	}
	public void playMusic(MusicSource source) {
		decoratedPlayer.playMusic(source);
	}

}
