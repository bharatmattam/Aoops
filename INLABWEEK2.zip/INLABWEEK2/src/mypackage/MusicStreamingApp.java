package mypackage;

public class MusicStreamingApp {
    public static void main(String[] args) {
        // Adapting music sources
        MusicSource localFile = new LocalFileAdapter("song.mp3");
        MusicSource onlineStream = new OnlineStreamAdapter("https://example.com/stream");
        MusicSource radioStation = new RadioStationAdapter("Radio XYZ");

        // Using basic music player
        MusicPlayer basicPlayer = new BasicMusicPlayer();

        // Playing from various sources
        System.out.println("Playing Local File:");
        basicPlayer.playMusic(localFile);

        System.out.println("\nPlaying Online Stream:");
        basicPlayer.playMusic(onlineStream);

        System.out.println("\nPlaying Radio Station:");
        basicPlayer.playMusic(radioStation);

        // Adding additional features with decorators
        MusicPlayer enhancedPlayer = new EqualizerDecorator(new VolumeControlDecorator(basicPlayer));

        System.out.println("\nEnhanced Playback with Equalizer and Volume Control:");
        enhancedPlayer.playMusic(onlineStream);
    }
}
