package mypackage;

class VolumeControlDecorator extends MusicPlayerDecorator {
    public VolumeControlDecorator(MusicPlayer decoratedPlayer) {
        super(decoratedPlayer);
    }

    public void playMusic(MusicSource source) {
        System.out.println("Adjusting volume...");
        super.playMusic(source);
    }
}
