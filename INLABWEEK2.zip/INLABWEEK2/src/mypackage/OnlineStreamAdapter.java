package mypackage;

public class OnlineStreamAdapter implements MusicSource{
	private String url;
	
	public OnlineStreamAdapter(String url) {
		this.url=url;
	}
	
	public void play() {
		System.out.println("Streaming music from url:"+url);
	}

}
