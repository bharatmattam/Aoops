package mypackage;

class LocalFileAdapter implements MusicSource{
	private String filepath;
	
	public LocalFileAdapter(String filepath) {
		this.filepath=filepath;
	}
	
	public void play() {
		System.out.println("Playing music from local file:"+filepath);
	}
}
