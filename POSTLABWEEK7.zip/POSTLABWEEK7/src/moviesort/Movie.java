package moviesort;

public class Movie {
    private double rating;
    private String name;
    private int year;

    // Constructor
    public Movie(double rating, String name, int year) {
        this.rating = rating;
        this.name = name;
        this.year = year;
    }

    // Getters
    public double getRating() {
        return rating;
    }

    public String getName() {
        return name;
    }

    public int getYear() {
        return year;
    }

    // toString method for displaying movie details
    @Override
    public String toString() {
        return rating + " " + name + " " + year;
    }
}
