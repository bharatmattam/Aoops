package client;

import logger.*;

public class Main {
    public static void main(String[] args) {
        // Configure handlers
        LogHandler infoHandler = new InfoHandler();
        LogHandler debugHandler = new DebugHandler();
        LogHandler errorHandler = new ErrorHandler();

        infoHandler.setNextHandler(debugHandler);
        debugHandler.setNextHandler(errorHandler);

        // Create commands
        Command infoCommand = new LogCommand(infoHandler);
        Command debugCommand = new LogCommand(debugHandler);
        Command errorCommand = new LogCommand(errorHandler);

        // Add commands to logger
        Logger logger = new Logger();
        logger.addCommand(infoCommand);
        logger.addCommand(debugCommand);
        logger.addCommand(errorCommand);

        // Process commands
        System.out.println("Processing Logs:");
        infoCommand.execute("System is running smoothly", LogLevel.INFO);
        debugCommand.execute("Debugging application module", LogLevel.DEBUG);
        errorCommand.execute("An error occurred during runtime", LogLevel.ERROR);
    }
}
