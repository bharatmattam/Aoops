package generics;

public class Main {
    public static void main(String[] args) {
        // Integer array
        Integer[] intArray = {5, 2, 9, 1, 5, 6};
        System.out.println("Before Sorting (Integer): ");
        BubbleSort.printArray(intArray);
        BubbleSort.bubbleSort(intArray);
        System.out.println("After Sorting (Integer): ");
        BubbleSort.printArray(intArray);

        // Double array
        Double[] doubleArray = {3.1, 2.2, 5.5, 1.0, 4.8};
        System.out.println("\nBefore Sorting (Double): ");
        BubbleSort.printArray(doubleArray);
        BubbleSort.bubbleSort(doubleArray);
        System.out.println("After Sorting (Double): ");
        BubbleSort.printArray(doubleArray);

        // String array
        String[] strArray = {"Banana", "Apple", "Mango", "Cherry", "Grape"};
        System.out.println("\nBefore Sorting (String): ");
        BubbleSort.printArray(strArray);
        BubbleSort.bubbleSort(strArray);
        System.out.println("After Sorting (String): ");
        BubbleSort.printArray(strArray);
    }
}
