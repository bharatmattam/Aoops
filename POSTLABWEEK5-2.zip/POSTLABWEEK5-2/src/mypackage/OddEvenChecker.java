package mypackage;

public class OddEvenChecker {

    // Method to check if the number is even or odd
    public String checkOddEven(int number) {
        if (number % 2 == 0) {
            return "Even";
        } else {
            return "Odd";
        }
    }
}
