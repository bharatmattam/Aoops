package mypackage;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class OddEvenCheckerTest {

    // Test for even number
    @Test
    public void testEvenNumber() {
        OddEvenChecker checker = new OddEvenChecker();
        assertEquals("Even", checker.checkOddEven(4));
    }

    // Test for odd number
    @Test
    public void testOddNumber() {
        OddEvenChecker checker = new OddEvenChecker();
        assertEquals("Odd", checker.checkOddEven(3));
    }

    // Test for zero (should be even)
    @Test
    public void testZero() {
        OddEvenChecker checker = new OddEvenChecker();
        assertEquals("Even", checker.checkOddEven(0));
    }

    // Test for negative even number
    @Test
    public void testNegativeEvenNumber() {
        OddEvenChecker checker = new OddEvenChecker();
        assertEquals("Even", checker.checkOddEven(-6));
    }

    // Test for negative odd number
    @Test
    public void testNegativeOddNumber() {
        OddEvenChecker checker = new OddEvenChecker();
        assertEquals("Odd", checker.checkOddEven(-5));
    }
}
