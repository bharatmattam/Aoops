package mypakcage;

abstract class EnemyFactory {
	public abstract Enemy createEnemy();
}

